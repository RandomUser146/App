package com.example.app.view_models;

public class VitalsViewModel {
}
