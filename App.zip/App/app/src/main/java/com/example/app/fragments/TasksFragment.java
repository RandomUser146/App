package com.example.app.fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.app.R;
import com.example.app.databinding.FragmentTasksBinding;
import com.example.app.view_models.TasksViewModel;

public class TasksFragment extends Fragment {

    TasksViewModel viewModel;
    FragmentTasksBinding binding;
    public TasksFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        if(viewModel == null)
            viewModel = new TasksViewModel();
        binding = FragmentTasksBinding.inflate(inflater,container,false);
        binding.setViewModel(viewModel);
        return binding.getRoot();
    }
}