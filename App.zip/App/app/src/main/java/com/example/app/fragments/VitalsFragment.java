package com.example.app.fragments;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.app.R;
import com.example.app.databinding.FragmentVitalsBinding;
import com.example.app.view_models.VitalsViewModel;

public class VitalsFragment extends Fragment {

    VitalsViewModel viewModel;
    FragmentVitalsBinding binding;
    public VitalsFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        if(viewModel == null) {
            viewModel = new VitalsViewModel();
        }
        binding = FragmentVitalsBinding.inflate(inflater, container, false);
        binding.setViewModel(viewModel);
        return binding.getRoot();
    }
}